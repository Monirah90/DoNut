
//
//  Atheerpage.swift
//  challengefriend
//
//  Created by leena alajlani on 19/12/2022.
//

import SwiftUI



struct ChallenegFriend: View {
    @State private var  challenge: String = ""
    init() {
        UITabBar.appearance().backgroundColor = UIColor(.white)
        }
    
  
    var body: some View {
       
            ZStack{
                
                Color.init("FirstColor").ignoresSafeArea()
                
                
                
                
                ZStack{
                    RoundedRectangle(cornerRadius:10 ).fill(.white)
                        .frame(width: 2000, height: 200)
                        .offset(x:-100,y:-400)
                    
                    
                    HStack{
                        
                        
                        Text("Challange My friend")
                            .font(.system(size:20))
                            .offset(x:50,y:-330)
                        
                        NavigationLink(destination: Settings(), label: {Image(systemName: "gear")
                                .foregroundColor(.black)
                                .frame(width: 100, height: 100)
                                
                                .font(.system(size: 27))
                        }).offset(x:65, y:-350)
                            .frame(maxWidth: 100, maxHeight: 24)
                    }
                }//HStack-1
                ZStack{
                    
                    Color.init("FirstColor")
                    
                    
                    TabView
                    {
                        
                        
                        //first page
                        VStack{
                            VStack{
                                Text("Days:21")
                                    .offset(y:-230)
                                
                                ContentView()
                                    .frame(width:20, height: 30)
                                    .offset(y:-150)
                                
                                Text("User Name 1")
                                    .fontWeight(.thin)
                                    .offset(y:-70)
                                
                            }
                            
                            Divider()
                                .offset(y:-50)
                            
                            VStack{
                                ContentView()
                                    .frame(width: 30, height: 30)
                                .offset(y:70)}
                            Text("User Name 2")
                                .fontWeight(.thin)
                                .offset(y:150)
                            
                        }    // end of first page
                        //start second page
                        
                        newPage()
                        
                        
                        //end second page
                        
                        
                        
                        
                        
                        
                    }
                    
                    
                    
                }
                
                .tabViewStyle(PageTabViewStyle())
                .indexViewStyle(.page(backgroundDisplayMode: .always))
                .cornerRadius(30)
                
                .frame(width: 380, height: 650)
                .padding(10)
                .offset(x:-00,y:70)
                
                
                
                
                
                
                
            }.ignoresSafeArea()
            
            
        
        
    }// var body: some View {
}////struct Atheerpage: View {

struct ChallenegFriend_Previews: PreviewProvider {
    static var previews: some View {
        ChallenegFriend()
    }
}



   



